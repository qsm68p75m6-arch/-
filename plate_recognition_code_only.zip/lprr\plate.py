from PIL import Image, ImageDraw, ImageFont
import numpy as np
import cv2
import torch
import os
from lprr.LPRNet import CHARS, build_lprnet
from lprr.hmt_ocr import recognize_hmt_plate

# 全局缓存 LPRNet
_lprnet_cache = None
_lprnet_device = None


def _get_lprnet():
    global _lprnet_cache, _lprnet_device
    if _lprnet_cache is not None:
        return _lprnet_cache, _lprnet_device
    net = build_lprnet(lpr_max_len=8, phase=True, class_num=len(CHARS), dropout_rate=0.5)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    net.to(device)
    _base = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(_base, "Final_LPRNet_model.pth")
    net.load_state_dict(torch.load(model_path, map_location=device, weights_only=False))
    net.eval()
    _lprnet_cache = net
    _lprnet_device = device
    return net, device


def transform(img):
    img = img.astype('float32')
    img /= 255
    img = np.transpose(img, (2, 0, 1))
    return img


def _lprnet_recognize(imk: np.ndarray):
    """用 LPRNet 识别，返回 (索引数组, 字符串)"""
    ims = [transform(imk)]
    ims = torch.Tensor(np.array(ims))
    lprnet, device = _get_lprnet()
    with torch.no_grad():
        prebs = lprnet(ims.to(device))
    prebs = prebs.cpu().detach().numpy()

    preb_labels = []
    for i in range(prebs.shape[0]):
        preb = prebs[i, :, :]
        blank_idx = len(CHARS) - 1  # '-' 的索引

        preb_label = []
        for j in range(preb.shape[1]):
            col = preb[:, j]
            best_idx = np.argmax(col)
            best_score = col[best_idx]
            blank_score = col[blank_idx]
            diff = best_score - blank_score
            # 前14个位置用较低阈值（2.0），后4个位置用较高阈值（8.0）避免尾部噪声
            threshold = 8.0 if j >= 14 else 2.0
            if best_idx != blank_idx and diff > threshold:
                preb_label.append(best_idx)
            else:
                preb_label.append(blank_idx)

        # CTC 解码：去除重复和 blank
        no_repeat = []
        pre_c = preb_label[0]
        if pre_c != blank_idx:
            no_repeat.append(pre_c)
        for c in preb_label:
            if (pre_c == c) or (c == blank_idx):
                if c == blank_idx:
                    pre_c = c
                continue
            no_repeat.append(c)
            pre_c = c
        preb_labels.append(no_repeat)

    plat_num = np.array(preb_labels)
    plate_str = ''
    if plat_num.size > 0 and plat_num.shape[1] > 0:
        # 大陆车牌最多 8 个字符，截断多余
        indices = plat_num[0][:8]
        plate_str = ''.join(CHARS[indices[i]] for i in range(len(indices)))
        # 位置感知字符修正：第3位及以后 U→0, I→1, O→0
        chars = list(plate_str)
        for i in range(2, len(chars)):
            if chars[i] == 'U':
                chars[i] = '0'
            elif chars[i] == 'I':
                chars[i] = '1'
            elif chars[i] == 'O':
                chars[i] = '0'
        plate_str = ''.join(chars)
        # 大陆车牌格式校验：第2位必须是字母（A-Z），如果不是则截断到第1位
        # 格式：省份汉字(1) + 字母(1) + 字母数字(5-6)
        if len(plate_str) >= 2:
            # 找到第一个汉字后的第一个字母位置
            has_chinese = any('\u4e00' <= c <= '\u9fff' for c in plate_str)
            if has_chinese:
                # 找到汉字结束位置
                chinese_end = 0
                for idx, ch in enumerate(plate_str):
                    if '\u4e00' <= ch <= '\u9fff':
                        chinese_end = idx + 1
                    else:
                        break
                # 如果汉字超过1个，截断到1个汉字
                if chinese_end > 1:
                    plate_str = plate_str[0] + plate_str[chinese_end:]
    return plat_num, plate_str


def _detect_plate_type(img_bgr: np.ndarray) -> str:
    """
    通过车牌底色判断识别引擎：
      'lprnet' : 蓝底（大陆标准牌）→ LPRNet
      'easyocr': 黄底（香港）/ 黑底（粤Z）/ 白底（台湾/澳门）→ EasyOCR
    """
    if img_bgr is None or img_bgr.size == 0:
        return 'lprnet'

    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    blue_mask = cv2.inRange(hsv, np.array([100, 80, 80]), np.array([130, 255, 255]))
    blue_ratio = np.sum(blue_mask > 0) / blue_mask.size

    plate_type = 'lprnet' if blue_ratio > 0.15 else 'easyocr'
    yellow_mask = cv2.inRange(hsv, np.array([20, 80, 80]), np.array([35, 255, 255]))
    yellow_ratio = np.sum(yellow_mask > 0) / yellow_mask.size
    white_mask = cv2.inRange(hsv, np.array([0, 0, 200]), np.array([180, 30, 255]))
    white_ratio = np.sum(white_mask > 0) / white_mask.size
    print(f'[DEBUG] 底色: 蓝={blue_ratio:.2%} 黄={yellow_ratio:.2%} 白={white_ratio:.2%} → {plate_type}')
    return plate_type


def _validate_plate_geometry(x1, y1, x2, y2) -> bool:
    """验证检测框几何形状是否符合车牌特征（宽高比 2.0~9.0）。"""
    bw = x2 - x1
    bh = y2 - y1
    if bw <= 0 or bh <= 0:
        return False
    aspect = bw / bh
    area = bw * bh
    if not (2.0 <= aspect <= 9.0):
        print(f'[DEBUG] 几何校验失败: 宽高比={aspect:.1f} (需2.0~9.0)')
        return False
    if area < 400:
        print(f'[DEBUG] 几何校验失败: 面积={area:.0f} (需>=400)')
        return False
    if bw < 20 or bh < 8:
        print(f'[DEBUG] 几何校验失败: 尺寸={bw}x{bh} (需>=20x8)')
        return False
    return True


def _validate_plate_text(text: str) -> bool:
    """验证识别文本是否符合车牌格式，拒绝纯字母/纯数字/字母过多。"""
    if not text or len(text) < 3:
        return False
    alpha_count = sum(1 for c in text if c.isalpha())
    digit_count = sum(1 for c in text if c.isdigit())
    special = len(text) - alpha_count - digit_count
    has_chinese = any('\u4e00' <= c <= '\u9fff' for c in text)
    if not has_chinese and special == 0:
        if alpha_count == len(text):
            print(f'[DEBUG] 文本校验跳过: 纯字母={repr(text)}')
            return False
        if digit_count == len(text):
            print(f'[DEBUG] 文本校验跳过: 纯数字={repr(text)}')
            return False
    if not has_chinese and len(text) >= 4 and alpha_count > len(text) * 0.6:
        print(f'[DEBUG] 文本校验跳过: 字母过多={repr(text)}')
        return False
    return True


def de_lpr(coord, im0):
    """
    车牌字符识别主函数。
    返回: (plat_num_array, plate_img, plate_str)
      - plat_num_array : CHARS 索引数组（兼容旧代码）
      - plate_img      : 94×24 缩略图
      - plate_str      : 完整车牌字符串（含港/澳等特殊字符）
    """
    h, w = im0.shape[:2]

    x1, y1, x2, y2 = round(coord[0]), round(coord[1]), round(coord[2]), round(coord[3])

    # 几何校验：宽高比不对的直接跳过
    if not _validate_plate_geometry(x1, y1, x2, y2):
        imk = np.zeros((24, 94, 3), dtype=np.uint8)
        return np.array([[]]), imk, ''

    bw, bh = x2 - x1, y2 - y1
    x1 = max(0, x1 - max(int(bw * 0.10), 6))
    y1 = max(0, y1 - max(int(bh * 0.10), 4))
    x2 = min(w, x2 + max(int(bw * 0.25), 12))
    y2 = min(h, y2 + max(int(bh * 0.10), 4))

    img = im0[y1:y2, x1:x2]
    imk = cv2.resize(img, (94, 24))

    plate_type = _detect_plate_type(img)

    if plate_type == 'lprnet':
        plat_num, plate_str = _lprnet_recognize(imk)
    else:
        hmt_result = recognize_hmt_plate(img)
        print(f'[DEBUG] EasyOCR 原始: {repr(hmt_result)}')

        if hmt_result:
            # 用ROI中心70%区域判断底色（避免padding带入的非牌面像素干扰）
            roi_h, roi_w = img.shape[:2]
            margin_x = int(roi_w * 0.15)
            margin_y = int(roi_h * 0.15)
            center_roi = img[margin_y:roi_h-margin_y, margin_x:roi_w-margin_x]
            if center_roi.size == 0:
                center_roi = img
            hsv_img = cv2.cvtColor(center_roi, cv2.COLOR_BGR2HSV)
            pixels = center_roi.shape[0] * center_roi.shape[1]

            yellow_ratio = np.sum(
                cv2.inRange(hsv_img, np.array([20, 80, 80]), np.array([35, 255, 255])) > 0
            ) / pixels
            # 白底检测用严格阈值（V>=200, S<=30），与_detect_plate_type一致
            white_mask = cv2.inRange(hsv_img, np.array([0, 0, 200]), np.array([180, 30, 255]))
            white_ratio = np.sum(white_mask > 0) / pixels
            # 黑色像素检测
            black_mask = cv2.inRange(hsv_img, np.array([0, 0, 0]), np.array([180, 255, 80]))
            black_ratio = np.sum(black_mask > 0) / pixels

            is_yellow = yellow_ratio > 0.15
            # 白底牌判定：白色占比高(>40%) 且 黑色占比低(<30%)
            is_white = white_ratio > 0.40 and black_ratio < 0.30
            # 黑底白字牌（粤Z）：黑色占比高(>25%)
            is_black_plate = black_ratio > 0.25
            if is_black_plate:
                is_white = False
            print(f'[DEBUG] 中心底色: 白={white_ratio:.2%} 黑={black_ratio:.2%} 黄={yellow_ratio:.2%} is_white={is_white} is_black={is_black_plate}')

            # 已识别出"粤"字的情况：修正 粤Z 格式
            if '粤' in hmt_result and not is_yellow and not is_white:
                # 找到粤字位置，提取后面的内容
                idx = hmt_result.index('粤')
                after_yue = hmt_result[idx+1:]  # 粤后面的内容
                # 去掉 Z 的误识别（2、1、Z）
                while after_yue and after_yue[0] in ('2', '1', 'Z', '·'):
                    after_yue = after_yue[1:]
                # 去掉末尾的港澳误识别
                after_yue = after_yue.rstrip('港澳')
                if len(after_yue) >= 3:
                    # 粤Z牌中间部分首字符如果是 '0' 且后面跟数字，可能是 M 的误识别
                    if after_yue[0] == '0' and len(after_yue) >= 2 and after_yue[1].isdigit():
                        after_yue = 'M' + after_yue[1:]
                    hmt_result = '粤Z·' + after_yue + '港'
                    print(f'[DEBUG] 粤Z修正: {repr(hmt_result)}')

            # 只有黑底（非黄非白）才做粤Z补全
            # 额外要求：原始OCR结果至少4个字符，防止垃圾短结果被误补全
            if (not is_yellow and not is_white and '粤' not in hmt_result
                    and 4 <= len(hmt_result) <= 8):                # 黑底粤Z牌处理
                # EasyOCR 常见误识别：粤→1/2/其他, Z→2, 整体偏移
                core = hmt_result

                # 精准剥离前导误识别字符：
                # 只剥离前1-2个最像粤Z误识别的字符，保留后续有效内容
                stripped = core
                # 首字符是'1'或'2'且后面还有足够字符 → 可能是"粤"的误识别
                if len(stripped) >= 4 and stripped[0] in ('1', '2', 'Q'):
                    stripped = stripped[1:]
                # 剥离后首字符是'Z'或'2' → 可能是"Z"的误识别
                if len(stripped) >= 3 and stripped[0] in ('Z', '2', '1'):
                    stripped = stripped[1:]

                # 如果剥离后太短，回退用原始结果
                if len(stripped) >= 3:
                    core = stripped

                # 粤Z牌中间部分长度3-5，超出则取后4位
                if len(core) > 5:
                    core = core[-4:]
                elif len(core) < 3 and len(hmt_result) >= 4:
                    core = hmt_result[-4:]  # 取原始结果后4位

                # core 至少需要3个字符才做补全（2字符以下说明识别失败）
                if len(core) >= 3:
                    hmt_result = '粤Z·' + core + '港'
                    print(f'[DEBUG] 粤Z补全: {repr(hmt_result)}')
                else:
                    print(f'[DEBUG] 粤Z补全跳过(core太短={repr(core)})')

            plate_str = hmt_result
            # 把能映射到 CHARS 的字符转成索引（兼容旧代码 shape 检查）
            indices = [CHARS.index(c) for c in hmt_result if c in CHARS]
            plat_num = np.array([indices]) if indices else np.array([[]])
        else:
            # EasyOCR 无结果，回退 LPRNet
            plat_num, plate_str = _lprnet_recognize(imk)

    # 文本校验：拒绝明显无效的识别结果
    if not _validate_plate_text(plate_str):
        # EasyOCR路径不回退LPRNet（LPRNet是为蓝牌训练的，对白底/黑底牌效果极差）
        # 直接置空，让上层跳过该检测框
        print(f'[DEBUG] 文本校验失败: {repr(plate_str)} → 置空')
        plate_str = ''
        plat_num = np.array([[]])

    return plat_num, imk, plate_str
