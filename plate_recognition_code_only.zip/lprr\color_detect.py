"""
基于颜色的车牌区域补充检测
- 对黄底牌（香港车尾）：在下方搜索粤Z牌
- 对黑底牌（粤Z）：在上方搜索香港本地牌
"""
import cv2
import numpy as np


def _iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    if inter == 0:
        return 0.0
    return inter / ((ax2-ax1)*(ay2-ay1) + (bx2-bx1)*(by2-by1) - inter)


def _is_yellow_plate(img_bgr, x1, y1, x2, y2) -> bool:
    roi = img_bgr[int(y1):int(y2), int(x1):int(x2)]
    if roi.size == 0:
        return False
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, np.array([20, 80, 80]), np.array([35, 255, 255]))
    return np.sum(mask > 0) / mask.size > 0.15


def _is_black_plate(img_bgr, x1, y1, x2, y2) -> bool:
    roi = img_bgr[int(y1):int(y2), int(x1):int(x2)]
    if roi.size == 0:
        return False
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([180, 255, 80]))
    return np.sum(mask > 0) / mask.size > 0.15


def find_plate_above(img_bgr: np.ndarray, ref_box: list) -> list:
    """在粤Z牌正上方搜索香港本地牌（白底/黄底）。"""
    h, w = img_bgr.shape[:2]
    rx1, ry1, rx2, ry2 = int(ref_box[0]), int(ref_box[1]), int(ref_box[2]), int(ref_box[3])
    rh = ry2 - ry1
    rw = rx2 - rx1

    for gap_ratio in [0.1, 0.3, 0.5, 0.8, 1.0, 1.5]:
        gap = int(rh * gap_ratio)
        by2 = ry1 - gap
        by1 = by2 - rh
        if by1 < 0 or by2 <= by1:
            continue

        bx1 = max(0, rx1 - int(rw * 0.1))
        bx2 = min(w, rx2 + int(rw * 0.1))
        roi = img_bgr[by1:by2, bx1:bx2]
        if roi.size == 0:
            continue

        hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
        pixels = roi.shape[0] * roi.shape[1]
        white_r = np.sum(cv2.inRange(hsv, np.array([0, 0, 180]), np.array([180, 50, 255])) > 0) / pixels
        yellow_r = np.sum(cv2.inRange(hsv, np.array([20, 80, 80]), np.array([35, 255, 255])) > 0) / pixels

        if white_r > 0.20 or yellow_r > 0.15:
            return [[bx1, by1, bx2, by2, 0.55]]

    return []


def find_plate_below(img_bgr: np.ndarray, ref_box: list,
                     search_ratio: float = 3.0,
                     white_thresh: int = 400) -> list:
    """在黄底牌下方搜索粤Z牌（黑底白字）。"""
    h, w = img_bgr.shape[:2]
    rx1, ry1, rx2, ry2 = int(ref_box[0]), int(ref_box[1]), int(ref_box[2]), int(ref_box[3])
    rh = ry2 - ry1
    rw = rx2 - rx1

    sx1 = max(0, rx1 - int(rw * 0.2))
    sy1 = ry2
    sx2 = min(w, rx2 + int(rw * 0.2))
    sy2 = min(h, ry2 + int(rh * search_ratio))

    if sy2 <= sy1 or sx2 <= sx1:
        return []

    roi = img_bgr[sy1:sy2, sx1:sx2]
    roi_h, roi_w = roi.shape[:2]

    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    white_mask = cv2.inRange(hsv, np.array([0, 0, 160]), np.array([180, 60, 255]))
    h_proj = np.sum(white_mask, axis=1)

    in_region = False
    regions = []
    start = 0
    for i, v in enumerate(h_proj):
        if v > white_thresh and not in_region:
            in_region = True
            start = i
        elif v <= white_thresh and in_region:
            in_region = False
            regions.append((start, i))
    if in_region:
        regions.append((start, roi_h))

    results = []
    for (r_start, r_end) in regions:
        region_h = r_end - r_start
        if not (rh * 0.4 <= region_h <= rh * 2.5):
            continue

        row_mask = white_mask[r_start:r_end, :]
        v_proj = np.sum(row_mask, axis=0)
        cols = np.where(v_proj > region_h * 5)[0]
        if len(cols) < 10:
            continue

        bx1 = sx1 + int(cols[0])
        bx2 = sx1 + int(cols[-1]) + 1
        by1 = sy1 + r_start
        by2 = sy1 + r_end

        bw = bx2 - bx1
        bh_box = by2 - by1
        if bh_box == 0 or bw * bh_box < 500:
            continue
        if not (1.5 <= bw / bh_box <= 9.0):
            continue

        results.append([bx1, by1, bx2, by2, 0.6])

    return results


def _overlap_or_close(box_a, box_b, iou_thresh=0.3, distance_thresh_ratio=0.5):
    """判断两个框是否重叠(IoU>阈值)或中心点距离接近。"""
    iou_val = _iou(box_a, box_b)
    if iou_val > iou_thresh:
        return True
    # 中心点距离检查：如果两框中心距 < 较大框对角线 * ratio，视为重复
    cx_a = (box_a[0] + box_a[2]) / 2
    cy_a = (box_a[1] + box_a[3]) / 2
    cx_b = (box_b[0] + box_b[2]) / 2
    cy_b = (box_b[1] + box_b[3]) / 2
    dist = ((cx_a - cx_b)**2 + (cy_a - cy_b)**2) ** 0.5
    # 用两框中较大的对角线作为参考
    diag_a = ((box_a[2]-box_a[0])**2 + (box_a[3]-box_a[1])**2) ** 0.5
    diag_b = ((box_b[2]-box_b[0])**2 + (box_b[3]-box_b[1])**2) ** 0.5
    max_diag = max(diag_a, diag_b)
    return dist < max_diag * distance_thresh_ratio


def detect_extra_plates(img_bgr: np.ndarray,
                        existing_boxes: list,
                        iou_thresh: float = 0.3) -> list:
    """
    双向补充检测：
    - 黄底牌 → 在下方找粤Z牌
    - 黑底牌（粤Z）→ 在上方找香港本地牌
    """
    new_boxes = []

    for ref in existing_boxes:
        rx1, ry1, rx2, ry2 = int(ref[0]), int(ref[1]), int(ref[2]), int(ref[3])

        if _is_yellow_plate(img_bgr, rx1, ry1, rx2, ry2):
            candidates = find_plate_below(img_bgr, ref)
        elif _is_black_plate(img_bgr, rx1, ry1, rx2, ry2):
            candidates = find_plate_above(img_bgr, ref)
        else:
            continue

        for cand in candidates:
            if any(_iou(cand[:4], eb[:4]) > iou_thresh for eb in existing_boxes):
                continue
            if any(_iou(cand[:4], nb[:4]) > iou_thresh for nb in new_boxes):
                continue
            new_boxes.append(cand)

    return new_boxes
