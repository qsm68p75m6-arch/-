import torch.nn as nn
import torch

# CHARS = ['jing', 'hu', 'jin', 'yu', 'yi', 'jin', 'meng', 'liao', 'ji', 'hei',
#          'su', 'zhe', 'wan', 'min', 'gan', 'lu', 'yu', 'e', 'xiang', 'yue',
#          'gui', 'qiong', 'chuan', 'gui', 'yun', 'zang', 'shan', 'gan', 'qing', 'ning',
#          'xin',
#          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
#          'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
#          'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
#          'W', 'X', 'Y', 'Z', 'I', 'O', '-'
#          ]
CHARS = ['京', '沪', '津', '渝', '冀', '晋', '蒙', '辽', '吉', '黑',
         '苏', '浙', '皖', '闽', '赣', '鲁', '豫', '鄂', '湘', '粤',
         '桂', '琼', '川', '贵', '云', '藏', '陕', '甘', '青', '宁',
         '新',
         '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
         'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
         'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
         'W', 'X', 'Y', 'Z', 'I', 'O', '-'
         ]
class small_basic_block(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(small_basic_block, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ch_in, ch_out // 4, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(ch_out // 4, ch_out // 4, kernel_size=(3, 1), padding=(1, 0)),
            nn.ReLU(),
            nn.Conv2d(ch_out // 4, ch_out // 4, kernel_size=(1, 3), padding=(0, 1)),
            nn.ReLU(),
            nn.Conv2d(ch_out // 4, ch_out, kernel_size=1),
        )
    def forward(self, x):
        return self.block(x)

class LPRNet(nn.Module):
    def __init__(self, lpr_max_len, phase, class_num, dropout_rate):
        super(LPRNet, self).__init__()
        self.phase = phase
        self.lpr_max_len = lpr_max_len
        self.class_num = class_num
        self.backbone = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=64, kernel_size=3, stride=1), # 0
            nn.BatchNorm2d(num_features=64),
            nn.ReLU(),  # 2
            nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 1, 1)),
            small_basic_block(ch_in=64, ch_out=128),    # *** 4 ***
            nn.BatchNorm2d(num_features=128),
            nn.ReLU(),  # 6
            nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(2, 1, 2)),
            small_basic_block(ch_in=64, ch_out=256),   # 8
            nn.BatchNorm2d(num_features=256),
            nn.ReLU(),  # 10
            small_basic_block(ch_in=256, ch_out=256),   # *** 11 ***
            nn.BatchNorm2d(num_features=256),   # 12
            nn.ReLU(),
            nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(4, 1, 2)),  # 14
            nn.Dropout(dropout_rate),
            nn.Conv2d(in_channels=64, out_channels=256, kernel_size=(1, 4), stride=1),  # 16
            nn.BatchNorm2d(num_features=256),
            nn.ReLU(),  # 18
            nn.Dropout(dropout_rate),
            nn.Conv2d(in_channels=256, out_channels=class_num, kernel_size=(13, 1), stride=1), # 20
            nn.BatchNorm2d(num_features=class_num),
            nn.ReLU(),  # *** 22 ***
        )
        self.container = nn.Sequential(
            nn.Conv2d(in_channels=448+self.class_num, out_channels=self.class_num, kernel_size=(1, 1), stride=(1, 1)),
            # nn.BatchNorm2d(num_features=self.class_num),
            # nn.ReLU(),
            # nn.Conv2d(in_channels=self.class_num, out_channels=self.lpr_max_len+1, kernel_size=3, stride=2),
            # nn.ReLU(),
        )

    def forward(self, x):
        keep_features = list()
        for i, layer in enumerate(self.backbone.children()):
            x = layer(x)
            if i in [2, 6, 13, 22]: # [2, 4, 8, 11, 22]
                keep_features.append(x)

        global_context = list()
        for i, f in enumerate(keep_features):
            if i in [0, 1]:
                f = nn.AvgPool2d(kernel_size=5, stride=5)(f)
            if i in [2]:
                f = nn.AvgPool2d(kernel_size=(4, 10), stride=(4, 2))(f)
            f_pow = torch.pow(f, 2)
            f_mean = torch.mean(f_pow)
            f = torch.div(f, f_mean)
            global_context.append(f)

        x = torch.cat(global_context, 1)
        x = self.container(x)
        logits = torch.mean(x, dim=2)

        return logits

def build_lprnet(lpr_max_len=8, phase=False, class_num=66, dropout_rate=0.5):

    Net = LPRNet(lpr_max_len, phase, class_num, dropout_rate)

    if phase == "train":
        return Net.train()
    else:
        return Net.eval()


# 大陆省份汉字集合（CHARS 前31个）
MAINLAND_CHARS = set(CHARS[:31])

def identify_plate_region(plate_str):
    """
    根据识别出的车牌字符串判断车牌所属地区。

    大陆车牌：首字符为省份汉字，格式如 粤A12345
    香港车牌：纯字母+数字，长度5-8，无汉字，字母在前
    澳门车牌：纯字母+数字，长度4-6，无汉字，字母在前
    台湾车牌：纯字母+数字，长度6-8，无汉字，字母在前

    返回: (region_name, region_code)
      region_code: 'mainland' / 'hongkong' / 'macau' / 'taiwan' / 'unknown'
    """
    if not plate_str:
        return ('未知', 'unknown')

    # 大陆车牌：首字符是省份汉字
    if plate_str[0] in MAINLAND_CHARS:
        return ('大陆', 'mainland')

    # 港澳台车牌：全部由字母和数字组成（无汉字）
    alpha_num = plate_str.replace('-', '').replace(' ', '')
    if not alpha_num:
        return ('未知', 'unknown')

    has_chinese = any('\u4e00' <= c <= '\u9fff' for c in alpha_num)
    if has_chinese:
        return ('未知', 'unknown')

    letters = [c for c in alpha_num if c.isalpha()]
    digits = [c for c in alpha_num if c.isdigit()]
    total_len = len(alpha_num)

    # 香港车牌规则：
    #   私家车: 2字母 + 4数字 (AB1234) 或 2字母 + 5数字 (AB12345)
    #   商用车: 1字母 + 4数字 (A1234) 或 1字母 + 5数字
    #   特殊: 字母开头，长度5-8
    if (1 <= len(letters) <= 3 and 4 <= len(digits) <= 5
            and alpha_num[0].isalpha() and total_len in range(5, 9)):
        # 香港车牌字母通常在前，数字在后
        # 进一步区分：香港车牌字母数量较少（1-2个），台湾较多（2-3个）
        if len(letters) <= 2:
            return ('香港', 'hongkong')

    # 澳门车牌规则：
    #   私家车: 2字母 + 2数字 + 2数字 (AB1234，去连字符后)，长度6
    #   摩托车: 2字母 + 2数字，长度4
    if (len(letters) == 2 and len(digits) in (2, 4)
            and alpha_num[0].isalpha() and total_len in (4, 6)):
        return ('澳门', 'macau')

    # 台湾车牌规则：
    #   旧式: 2字母 + 4数字 (AB-1234)，长度6
    #   新式: 3字母 + 4数字 (ABC-1234)，长度7
    #   机车: 3字母 + 3数字，长度6
    if (2 <= len(letters) <= 3 and 3 <= len(digits) <= 4
            and alpha_num[0].isalpha() and total_len in (6, 7)):
        return ('台湾', 'taiwan')

    # 兜底：纯字母数字但无法精确匹配，标记为港澳台待确认
    if not has_chinese and total_len >= 4:
        return ('港澳台', 'hmt')

    return ('未知', 'unknown')
