"""
港澳台车牌 OCR —— 基于 EasyOCR
识别纯字母数字车牌（香港/澳门/台湾）及粤Z跨境牌
"""
import cv2
import numpy as np

_reader = None


def _get_reader():
    global _reader
    if _reader is None:
        import easyocr
        _reader = easyocr.Reader(['ch_sim', 'en'], gpu=False, verbose=False)
    return _reader


# 合法字符集
_VALID_CHARS = set(
    '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ'
    '粤港澳京沪津渝冀晋蒙辽吉黑苏浙皖闽赣鲁豫鄂湘桂琼川贵云藏陕甘青宁新·'
)


def _preprocess_variants(img_bgr: np.ndarray):
    """生成多种预处理变体，提高识别成功率。"""
    variants = []
    target_h = 96
    scale = target_h / img_bgr.shape[0]
    target_w = max(int(img_bgr.shape[1] * scale), 120)

    # 变体0：直接放大
    big = cv2.resize(img_bgr, (target_w, target_h), interpolation=cv2.INTER_CUBIC)
    variants.append(big)

    # 变体1：放大 + 轻微锐化
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharp = cv2.filter2D(big, -1, kernel)
    variants.append(sharp)

    # 变体2：2倍放大
    big2 = cv2.resize(img_bgr, (target_w * 2, target_h * 2), interpolation=cv2.INTER_CUBIC)
    variants.append(big2)

    # 变体3：2倍放大 + 锐化
    sharp2 = cv2.filter2D(big2, -1, kernel)
    variants.append(sharp2)

    # 变体4：CLAHE 对比度增强
    lab = cv2.cvtColor(big, cv2.COLOR_BGR2LAB)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(4, 4))
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    variants.append(enhanced)

    # 变体5：CLAHE + 锐化
    variants.append(cv2.filter2D(enhanced, -1, kernel))

    return variants


def _run_ocr(img, reader, min_conf: float = 0.01) -> str:
    """对单张图运行 EasyOCR，返回清理后的字符串。"""
    try:
        results = reader.readtext(img, detail=1, paragraph=False)
    except Exception:
        return ''
    if not results:
        return ''
    results_sorted = sorted(results, key=lambda r: r[0][0][0])
    # 降低置信度阈值，避免漏掉低质量图像的识别结果
    text_parts = [r[1] for r in results_sorted if r[2] > min_conf]
    if not text_parts:
        return ''
    text = ''.join(text_parts).upper()
    return ''.join(c for c in text if c in _VALID_CHARS)


def _score_result(text: str) -> float:
    """
    对识别结果打分，分数越高越好。
    综合考虑：字符数量、字母数字比例、是否包含有效车牌字符。
    """
    if not text:
        return 0.0
    alnum = sum(1 for c in text if c.isalnum())
    # 字母数字字符数 × 字母数字比例
    ratio = alnum / len(text)
    return alnum * ratio


def _fix_common_errors(text: str) -> str:
    """修正 EasyOCR 对车牌字体的常见误识别。"""
    if not text:
        return text
    result = list(text)
    n = len(result)

    # 首字符修正
    if result[0] == 'U' and n >= 2:
        result[0] = 'M'  # U→M（香港M牌常见）

    # 位置感知修正
    for i in range(min(2, n)):
        if result[i] == 'O' and n >= 4:
            if i + 1 < n and result[i + 1].isdigit():
                result[i] = '0'

    # 第3位及以后：O/I/Q 优先视为数字
    for i in range(2, n):
        if result[i] == 'O':
            result[i] = '0'
        elif result[i] == 'I':
            result[i] = '1'
        elif result[i] == 'Q':
            result[i] = '0'

    return ''.join(result)


def recognize_hmt_plate(img_bgr: np.ndarray) -> str:
    """
    识别港澳台/粤Z车牌。
    对多种预处理变体分别识别，取综合评分最高的结果。
    """
    if img_bgr is None or img_bgr.size == 0:
        return ''

    reader = _get_reader()
    variants = _preprocess_variants(img_bgr)

    best = ''
    best_score = 0.0
    for v in variants:
        result = _run_ocr(v, reader, min_conf=0.01)
        score = _score_result(result)
        if score > best_score:
            best_score = score
            best = result

    best = _fix_common_errors(best)
    return best
