"""
ONNX Runtime inference for license plate detection.
Minimal dependencies: onnxruntime, numpy, opencv-python.

Model: YOLOv10n plate detector
Input:  images    [1, 3, 640, 640]  float32, normalized [0, 1]
Output: output0   [1, 5, 8400]      raw grid predictions

Each of 8400 predictions: [cx, cy, w, h, conf]
After NMS, returns list of [x1, y1, x2, y2, conf] in pixel coordinates.
"""
import cv2
import numpy as np
import onnxruntime as ort


class PlateDetectorONNX:
    def __init__(self, model_path, conf_threshold=0.5, iou_threshold=0.45):
        """
        Args:
            model_path: Path to ONNX model file
            conf_threshold: Confidence threshold for detections
            iou_threshold: IoU threshold for NMS
        """
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold

        sess_opts = ort.SessionOptions()
        sess_opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.session = ort.InferenceSession(model_path, sess_opts,
                                            providers=['CPUExecutionProvider'])
        self.input_name = self.session.get_inputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape
        _, _, self.img_h, self.img_w = self.input_shape

    def _preprocess(self, image_bgr):
        """Letterbox resize and normalize to [0,1] NCHW format."""
        h, w = image_bgr.shape[:2]
        scale = min(self.img_h / h, self.img_w / w)
        new_w, new_h = int(w * scale), int(h * scale)

        resized = cv2.resize(image_bgr, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        letterbox = np.full((self.img_h, self.img_w, 3), 114, dtype=np.uint8)
        pad_x = (self.img_w - new_w) // 2
        pad_y = (self.img_h - new_h) // 2
        letterbox[pad_y:pad_y+new_h, pad_x:pad_x+new_w] = resized

        blob = letterbox.astype(np.float32) / 255.0
        blob = blob.transpose(2, 0, 1)[np.newaxis, ...]  # HWC -> NCHW
        return blob, scale, pad_x, pad_y, (w, h)

    def _postprocess(self, output, scale, pad_x, pad_y, orig_size):
        """Decode raw grid output -> NMS -> pixel coords."""
        preds = output[0]  # [5, 8400]

        # Filter by confidence
        conf_mask = preds[4, :] > self.conf_threshold
        preds = preds[:, conf_mask]  # [5, N]
        if preds.shape[1] == 0:
            return np.empty((0, 5))

        # Convert cxcywh -> xyxy
        boxes_cxcywh = preds[:4, :].T  # [N, 4]
        xyxy = np.zeros_like(boxes_cxcywh)
        xyxy[:, 0] = boxes_cxcywh[:, 0] - boxes_cxcywh[:, 2] / 2  # x1
        xyxy[:, 1] = boxes_cxcywh[:, 1] - boxes_cxcywh[:, 3] / 2  # y1
        xyxy[:, 2] = boxes_cxcywh[:, 0] + boxes_cxcywh[:, 2] / 2  # x2
        xyxy[:, 3] = boxes_cxcywh[:, 1] + boxes_cxcywh[:, 3] / 2  # y2

        scores = preds[4, :]

        # NMS
        indices = cv2.dnn.NMSBoxes(
            xyxy.tolist(), scores.tolist(),
            self.conf_threshold, self.iou_threshold
        )

        if len(indices) == 0:
            return np.empty((0, 5))

        dets = np.zeros((len(indices), 5), dtype=np.float32)
        for i, idx in enumerate(indices.flatten()):
            # Rescale from letterbox to original image
            x1 = (xyxy[idx, 0] - pad_x) / scale
            y1 = (xyxy[idx, 1] - pad_y) / scale
            x2 = (xyxy[idx, 2] - pad_x) / scale
            y2 = (xyxy[idx, 3] - pad_y) / scale

            # Clip to image bounds
            x1 = np.clip(x1, 0, orig_size[0])
            y1 = np.clip(y1, 0, orig_size[1])
            x2 = np.clip(x2, 0, orig_size[0])
            y2 = np.clip(y2, 0, orig_size[1])

            dets[i] = [x1, y1, x2, y2, scores[idx]]

        return dets

    def detect(self, image_bgr):
        """Run detection on a BGR image.

        Returns:
            detections: np.ndarray of shape [N, 5] -> [x1, y1, x2, y2, conf]
        """
        blob, scale, pad_x, pad_y, orig_size = self._preprocess(image_bgr)
        outputs = self.session.run(None, {self.input_name: blob})
        return self._postprocess(outputs[0], scale, pad_x, pad_y, orig_size)


def draw_detections(image_bgr, detections, color=(0, 255, 0), thickness=2):
    """Draw bounding boxes on image. Returns annotated image."""
    img = image_bgr.copy()
    for det in detections:
        x1, y1, x2, y2, conf = map(int, det[:4].tolist() + [0])
        cv2.rectangle(img, (x1, y1), (x2, y2), color, thickness)
        label = f'Plate: {det[4]:.2f}'
        (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)
        cv2.rectangle(img, (x1, y1 - lh - 10), (x1 + lw, y1), color, -1)
        cv2.putText(img, label, (x1, y1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)
    return img


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='ONNX Plate Detection')
    parser.add_argument('--model', type=str, default='deployment/model/plate_detector_fp32.onnx')
    parser.add_argument('--image', type=str, required=True)
    parser.add_argument('--output', type=str, default=None)
    parser.add_argument('--conf', type=float, default=0.5)
    args = parser.parse_args()

    detector = PlateDetectorONNX(args.model, conf_threshold=args.conf)
    image = cv2.imread(args.image)
    if image is None:
        raise FileNotFoundError(f"Cannot read image: {args.image}")

    dets = detector.detect(image)
    print(f"Found {len(dets)} plate(s)")
    for i, det in enumerate(dets):
        print(f"  [{i+1}] x1={det[0]:.0f} y1={det[1]:.0f} x2={det[2]:.0f} y2={det[3]:.0f} conf={det[4]:.3f}")

    annotated = draw_detections(image, dets)
    out_path = args.output or 'output_onnx.jpg'
    cv2.imwrite(out_path, annotated)
    print(f"Saved: {out_path}")
    cv2.imshow('ONNX Detection', annotated)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
