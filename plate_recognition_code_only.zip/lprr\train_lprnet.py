# -*- coding: utf-8 -*-
"""
LPRNet 微调训练脚本（支持港澳台 + 大陆混合数据）

数据目录格式（--data 参数指定根目录）：
  <data_root>/
    images/   *.jpg  (94x24)
    labels/   *.txt  (车牌字符串，如 AB1234 或 粤A12345)

用法示例：
  # 仅用港澳台合成数据微调
  python lprr/train_lprnet.py --data lprr/hmt_data --pretrained lprr/Final_LPRNet_model.pth

  # 混合多个数据目录（用逗号分隔）
  python lprr/train_lprnet.py --data lprr/hmt_data,lprr/mainland_data --pretrained lprr/Final_LPRNet_model.pth

  # 从头训练（不加载预训练权重）
  python lprr/train_lprnet.py --data lprr/hmt_data
"""

import os
import sys
import random
import argparse
import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, ConcatDataset

# 将项目根目录加入路径，使 lprr 包可以被正确导入
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from lprr.LPRNet import CHARS, build_lprnet

# ---------------------------------------------------------------------------
# 字符映射
# ---------------------------------------------------------------------------

CHAR2IDX = {c: i for i, c in enumerate(CHARS)}
BLANK_IDX = len(CHARS) - 1  # '-' 是 CTC blank

# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class PlateDataset(Dataset):
    def __init__(self, data_dir, img_w=94, img_h=24, augment=True):
        self.img_dir = os.path.join(data_dir, 'images')
        self.lbl_dir = os.path.join(data_dir, 'labels')
        self.img_w = img_w
        self.img_h = img_h
        self.augment = augment

        # 收集所有有对应标注的图片
        self.samples = []
        for fname in os.listdir(self.img_dir):
            if not fname.lower().endswith(('.jpg', '.png', '.jpeg')):
                continue
            stem = os.path.splitext(fname)[0]
            lbl_path = os.path.join(self.lbl_dir, stem + '.txt')
            if not os.path.exists(lbl_path):
                continue
            with open(lbl_path, 'r', encoding='utf-8') as f:
                label = f.read().strip()
            # 过滤掉含有 CHARS 之外字符的标注
            if all(c in CHAR2IDX for c in label) and 1 <= len(label) <= 8:
                self.samples.append((os.path.join(self.img_dir, fname), label))

        if len(self.samples) == 0:
            raise RuntimeError(f'在 {data_dir} 中未找到有效样本，请检查 images/ 和 labels/ 目录')

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]

        img = Image.open(img_path).convert('RGB')
        img = img.resize((self.img_w, self.img_h), Image.BILINEAR)

        if self.augment:
            img = self._augment(img)

        arr = np.array(img, dtype=np.float32) / 255.0          # [H, W, 3]
        arr = np.transpose(arr, (2, 0, 1))                      # [3, H, W]
        tensor = torch.from_numpy(arr)

        target = torch.tensor([CHAR2IDX[c] for c in label], dtype=torch.int32)
        return tensor, target, len(label)

    def _augment(self, img):
        arr = np.array(img, dtype=np.float32)
        arr += np.random.uniform(-15, 15)
        noise = np.random.normal(0, np.random.uniform(0, 6), arr.shape)
        arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
        return Image.fromarray(arr)


def collate_fn(batch):
    """将变长 target 序列打包成 CTC 所需格式。"""
    imgs, targets, lengths = zip(*batch)
    imgs = torch.stack(imgs, 0)
    targets_cat = torch.cat(targets, 0)          # 所有序列拼接
    lengths = torch.tensor(lengths, dtype=torch.int32)
    return imgs, targets_cat, lengths

# ---------------------------------------------------------------------------
# 训练 / 验证
# ---------------------------------------------------------------------------

def accuracy(preds, targets, lengths):
    """序列级准确率（完全匹配）。"""
    preds = preds.cpu().detach().numpy()          # [B, class_num, T]
    correct = 0
    offset = 0
    for i in range(len(lengths)):
        length = lengths[i].item()
        gt = targets[offset:offset + length].tolist()
        offset += length

        pred_seq = []
        prev = BLANK_IDX
        for t in range(preds.shape[2]):
            c = int(np.argmax(preds[i, :, t]))
            if c != prev and c != BLANK_IDX:
                pred_seq.append(c)
            prev = c

        if pred_seq == gt:
            correct += 1
    return correct / len(lengths)


def train_one_epoch(model, loader, optimizer, ctc_loss, device):
    model.train()
    total_loss = 0.0
    total_acc = 0.0

    for imgs, targets, lengths in loader:
        imgs = imgs.to(device)
        targets = targets.to(device)

        logits = model(imgs)                      # [B, class_num, T]
        log_probs = logits.log_softmax(1)         # CTC 需要 log_softmax
        # log_probs 形状需要 [T, B, class_num]
        log_probs = log_probs.permute(2, 0, 1)

        T = log_probs.size(0)
        B = log_probs.size(1)
        input_lengths = torch.full((B,), T, dtype=torch.int32)

        loss = ctc_loss(log_probs, targets.cpu(), input_lengths, lengths)

        optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
        optimizer.step()

        total_loss += loss.item()
        total_acc += accuracy(logits, targets.cpu(), lengths)

    n = len(loader)
    return total_loss / n, total_acc / n


@torch.no_grad()
def validate(model, loader, ctc_loss, device):
    model.eval()
    total_loss = 0.0
    total_acc = 0.0

    for imgs, targets, lengths in loader:
        imgs = imgs.to(device)
        logits = model(imgs)
        log_probs = logits.log_softmax(1).permute(2, 0, 1)
        T = log_probs.size(0)
        B = log_probs.size(1)
        input_lengths = torch.full((B,), T, dtype=torch.int32)
        loss = ctc_loss(log_probs, targets, input_lengths, lengths)
        total_loss += loss.item()
        total_acc += accuracy(logits, targets, lengths)

    n = len(loader)
    return total_loss / n, total_acc / n

# ---------------------------------------------------------------------------
# 主入口
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=str, required=True,
                        help='数据目录，多个目录用逗号分隔')
    parser.add_argument('--pretrained', type=str, default='',
                        help='预训练权重路径（留空则从头训练）')
    parser.add_argument('--save', type=str, default='lprr/lprnet_hmt.pth',
                        help='最优模型保存路径')
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--batch', type=int, default=128)
    parser.add_argument('--lr', type=float, default=1e-4,
                        help='学习率（微调建议 1e-4，从头训练建议 1e-3）')
    parser.add_argument('--val_split', type=float, default=0.1,
                        help='验证集比例')
    parser.add_argument('--workers', type=int, default=0,
                        help='DataLoader 工作进程数（Windows 建议设 0）')
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'使用设备: {device}')

    # ---- 加载数据集 ----
    data_dirs = [d.strip() for d in args.data.split(',')]
    datasets = []
    for d in data_dirs:
        print(f'加载数据集: {d}')
        datasets.append(PlateDataset(d, augment=True))

    full_dataset = ConcatDataset(datasets) if len(datasets) > 1 else datasets[0]
    total = len(full_dataset)
    val_size = max(1, int(total * args.val_split))
    train_size = total - val_size
    train_set, val_set = torch.utils.data.random_split(
        full_dataset, [train_size, val_size],
        generator=torch.Generator().manual_seed(42)
    )
    print(f'训练集: {train_size} 张，验证集: {val_size} 张')

    train_loader = DataLoader(train_set, batch_size=args.batch, shuffle=True,
                              num_workers=args.workers, collate_fn=collate_fn,
                              drop_last=True)
    val_loader = DataLoader(val_set, batch_size=args.batch, shuffle=False,
                            num_workers=args.workers, collate_fn=collate_fn)

    # ---- 构建模型 ----
    model = build_lprnet(lpr_max_len=8, phase='train',
                         class_num=len(CHARS), dropout_rate=0.5)
    if args.pretrained and os.path.exists(args.pretrained):
        print(f'加载预训练权重: {args.pretrained}')
        model.load_state_dict(torch.load(args.pretrained,
                                         map_location='cpu', weights_only=False))
    else:
        print('未加载预训练权重，从头训练')
    model.to(device)

    # ---- 优化器 & 损失 ----
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-5)
    # 每 15 个 epoch 学习率衰减到 0.1 倍
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.1)
    ctc_loss = nn.CTCLoss(blank=BLANK_IDX, reduction='mean', zero_infinity=True)

    # ---- 训练循环 ----
    best_val_acc = 0.0
    save_dir = os.path.dirname(args.save)
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        tr_loss, tr_acc = train_one_epoch(model, train_loader, optimizer, ctc_loss, device)
        val_loss, val_acc = validate(model, val_loader, ctc_loss, device)
        scheduler.step()

        print(f'Epoch [{epoch:3d}/{args.epochs}]  '
              f'train_loss={tr_loss:.4f}  train_acc={tr_acc:.4f}  '
              f'val_loss={val_loss:.4f}  val_acc={val_acc:.4f}  '
              f'lr={scheduler.get_last_lr()[0]:.2e}')

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), args.save)
            print(f'  -> 保存最优模型 (val_acc={val_acc:.4f})')

    print(f'\n训练完成，最优验证准确率: {best_val_acc:.4f}')
    print(f'模型已保存至: {args.save}')
    print('\n使用新模型时，修改 lprr/plate.py 第32行的权重路径：')
    print(f'  lprnet.load_state_dict(torch.load(r"{args.save}", ...))')


if __name__ == '__main__':
    main()
