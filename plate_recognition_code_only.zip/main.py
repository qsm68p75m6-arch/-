import os
import sys

# 必须在 PyQt5 之前导入 onnxruntime，否则 PyQt5 加载的 DLL 会与其冲突
from lprr.infer_onnx import PlateDetectorONNX

from eng2ch import cv2ImgAddText
## 导入设计好的检测界面
from PyQt5.QtWidgets import QApplication, QMainWindow
from utils.plots import plot_one_box2, plot_one_box3
from lprr.LPRNet import CHARS, build_lprnet, identify_plate_region
from PyQt5 import QtCore, QtGui, QtWidgets
from ui.main_window import Ui_MainWindow
from lprr.plate import de_lpr
from lprr.color_detect import detect_extra_plates, _iou, _overlap_or_close
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import numpy as np
import argparse
import random
import time
import cv2
import sys

# ONNX 模型默认路径
DEFAULT_ONNX_MODEL = r'lprr\plate_detector_fp32.onnx'



class mywindows(QMainWindow,Ui_MainWindow):

    def __init__(self):
        QMainWindow.__init__(self)
        Ui_MainWindow.__init__(self)
        self.timer_video = QtCore.QTimer()  # 创建定时器
        self.setupUi(self)#初始化界面
        self.init_slots()#初始化槽函数
        self.cap = cv2.VideoCapture()#初始化摄像头
        self.output_folder = 'output/'#定义检测图片/视频保存路径
        self.num_stop = 1  # 暂停与播放辅助信号，note：通过奇偶来控制暂停与播放
        self.flag=0#重要的标志位，用于判断画面中是否有车牌
        # 权重初始文件名
        self.openfile_name_model = None
        self.vid_writer = None




    def conf_set(self):
        self.doubleSpinBox.setValue(self.opt.conf_thres)
        self.doubleSpinBox_2.setValue(self.opt.iou_thres)
        self.doubleSpinBox.valueChanged.connect(lambda x: self.change_val(x, 'doubleSpinBox'))
        self.horizontalSlider.valueChanged.connect(lambda x: self.change_val(x, 'horizontalSlider'))
        self.doubleSpinBox_2.valueChanged.connect(lambda x: self.change_val(x, 'doubleSpinBox_2'))
        self.horizontalSlider_2.valueChanged.connect(lambda x: self.change_val(x, 'horizontalSlider_2'))
        pass

    def change_val(self, x, flag):
        if flag == 'doubleSpinBox':
            self.horizontalSlider.setValue(int(x*100))
        elif flag == 'horizontalSlider':
            self.doubleSpinBox.setValue(x/100)
            self.opt.conf_thres = x/100
            # 同步更新 ONNX 检测器阈值
            if hasattr(self, 'detector'):
                self.detector.conf_threshold = x/100
        elif flag == 'doubleSpinBox_2':
            self.horizontalSlider_2.setValue(int(x * 100))
        elif flag == 'horizontalSlider_2':
            self.doubleSpinBox_2.setValue(x/100)
            self.opt.iou_thres = x/100
            if hasattr(self, 'detector'):
                self.detector.iou_threshold = x/100


    def init_slots(self):
        self.pushButton_weights.clicked.connect(self.open_model)#权重初始化
        self.pushButton_img.clicked.connect(self.button_image_open)#打开图像
        self.pushButton_init.clicked.connect(self.model_init)#模型初始化
        self.pushButton_2.clicked.connect(self.button_video_open)#打开视频
        self.pushButton_3.clicked.connect(self.button_camera_open)#打开摄像头
        self.pushButton_stop.clicked.connect(self.button_video_stop)#停止/继续
        self.pushButton_finish.clicked.connect(self.finish_detect)#结束
        self.timer_video.timeout.connect(self.show_video_frame)  # 定时器超时，将槽绑定至show_video_frame



    # 打开 ONNX 模型文件
    def open_model(self):
        self.openfile_name_model, _ = QFileDialog.getOpenFileName(
            self.pushButton_weights, '选择ONNX模型文件', 'lprr', '*.onnx;;All Files(*)')
        if not self.openfile_name_model:
            QtWidgets.QMessageBox.warning(self, u"Warning", u"打开模型失败", buttons=QtWidgets.QMessageBox.Ok,
                                          defaultButton=QtWidgets.QMessageBox.Ok)
        else:
            print('加载ONNX模型地址为：' + str(self.openfile_name_model))

    def model_init(self):
        # 模型参数配置（保留 conf/iou 供 UI 联动使用）
        parser = argparse.ArgumentParser()
        parser.add_argument('--conf-thres', type=float, default=0.40, help='object confidence threshold')
        parser.add_argument('--iou-thres', type=float, default=0.45, help='IOU threshold for NMS')
        self.opt = parser.parse_args([])

        # 确定 ONNX 模型路径：优先使用按钮选择的，否则用默认路径
        onnx_path = self.openfile_name_model if self.openfile_name_model else DEFAULT_ONNX_MODEL
        print(f'加载 ONNX 模型：{onnx_path}')

        try:
            # 初始化 ONNX 检测器（纯 CPU，无需 CUDA）
            self.detector = PlateDetectorONNX(
                onnx_path,
                conf_threshold=self.opt.conf_thres,
                iou_threshold=self.opt.iou_thres
            )
            # 兼容旧代码中用到的 names / colors（只有一个类别：plate）
            self.names = ['plate']
            self.colors = [[random.randint(0, 255) for _ in range(3)]]
            print("model initial done")
            QtWidgets.QMessageBox.information(self, u"Notice", u"模型加载完成", buttons=QtWidgets.QMessageBox.Ok,
                                              defaultButton=QtWidgets.QMessageBox.Ok)
            self.conf_set()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, u"Error", f"模型加载失败：{e}", buttons=QtWidgets.QMessageBox.Ok,
                                           defaultButton=QtWidgets.QMessageBox.Ok)

    # 目标检测
    def detect(self, name_list, img):
        '''
        返回: (single_info, label, plate, la_img, plate_imgs, all_plate_strs)
        plate_imgs: 每块车牌的缩略图列表 [(img1, str1), (img2, str2), ...]
        '''
        # 最先复制原图，后续画框/写字不影响截图
        orig_img = img.copy()
        showimg = img
        single_info = []
        label = ''
        la_img = np.array([])
        plate = np.array([])
        all_plate_strs = []
        plate_imgs = []

        # ── 第一路：ONNX 检测器 ──────────────────────────────────────
        dets = self.detector.detect(showimg)
        if dets is None:
            dets = np.empty((0, 5))
        n_onnx = len(dets)  # 记录 ONNX 检测框数量

        # ── 第二路：颜色补充检测（找 ONNX 漏检的粤Z/黑底牌） ──────────
        if len(dets) > 0:
            extra = detect_extra_plates(showimg, dets.tolist())
            if extra:
                dets = np.vstack([dets, np.array(extra)])

        if len(dets) > 0:
            self.flag = 1

            for det_idx, det in enumerate(dets):
                x1, y1, x2, y2, conf = det
                xyxy = [x1, y1, x2, y2]

                plate, plate_img, plate_str = de_lpr(xyxy, orig_img)

                # 几何/文本校验失败→跳过该检测框
                if not plate_str:
                    continue

                # 补充检测框（非 ONNX）：如果 ONNX 框是黑底粤Z牌，
                # 则补充框是从上方找到的香港本地牌，不应该被补全为粤Z格式
                if det_idx >= n_onnx and plate_str.startswith('粤Z·') and n_onnx > 0:
                    ref_det = dets[0]
                    ref_roi = orig_img[int(ref_det[1]):int(ref_det[3]), int(ref_det[0]):int(ref_det[2])]
                    if ref_roi.size > 0:
                        import cv2 as _cv2
                        _hsv = _cv2.cvtColor(ref_roi, _cv2.COLOR_BGR2HSV)
                        _dark = _cv2.inRange(_hsv, np.array([0,0,0]), np.array([180,255,80]))
                        if np.sum(_dark > 0) / _dark.size > 0.15:
                            # ONNX 框是黑底，补充框是香港本地牌，去掉粤Z补全
                            # 提取中间部分作为原始识别结果
                            plate_str = plate_str.replace('粤Z·', '').replace('港', '').replace('澳', '')
                label = 'plate %.2f' % conf
                name_list.append('plate')

                single_info, label = plot_one_box3(
                    xyxy, showimg, label=label,
                    color=self.colors[0], line_thickness=2
                )

                if plate_str:
                    all_plate_strs.append(plate_str)

                    # 截图：始终用当前检测框自身坐标截取原始图
                    h_img, w_img = orig_img.shape[:2]
                    bw = max(int(x2 - x1), 1)
                    bh = max(int(y2 - y1), 1)
                    cx1 = max(0, int(x1) - max(int(bw * 0.05), 4))
                    cy1 = max(0, int(y1) - max(int(bh * 0.05), 2))
                    cx2 = min(w_img, int(x2) + max(int(bw * 0.05), 4))
                    cy2 = min(h_img, int(y2) + max(int(bh * 0.05), 2))
                    display_img = orig_img[cy1:cy2, cx1:cx2].copy()
                    if display_img.size == 0:
                        display_img = orig_img[int(y1):int(y2), int(x1):int(x2)].copy()
                    plate_imgs.append((display_img, plate_str))

                    # 标注位置：显示在车牌框右侧，右侧空间不够则显示在左侧
                    h_img, w_img = showimg.shape[:2]
                    text_size = 32
                    # 估算文字宽度（每个字符约 text_size * 0.6 像素）
                    text_w = int(len(plate_str) * text_size * 0.65)
                    text_x = int(x2) + 8
                    text_y = int((y1 + y2) / 2) - text_size // 2
                    # 右侧空间不够，改到左侧
                    if text_x + text_w > w_img:
                        text_x = max(0, int(x1) - text_w - 8)
                    # 垂直方向边界检查
                    text_y = max(0, min(text_y, h_img - text_size - 4))

                    if det_idx == 0:
                        text_color = (255, 0, 0)    # 红色（第一块牌）
                    else:
                        text_color = (0, 200, 255)  # 青色（第二块牌）

                    # cv2ImgAddText 返回新图，需要更新 showimg 引用
                    result = cv2ImgAddText(
                        showimg, plate_str,
                        text_x, text_y,
                        textColor=text_color, textSize=text_size
                    )
                    if result is not None and result.size > 0:
                        showimg = result
                        la_img = showimg

        # 兼容旧代码：plate_img 取第一块牌
        first_plate_img = plate_imgs[0][0] if plate_imgs else np.array([])
        return single_info, label, plate, la_img, first_plate_img, all_plate_strs, plate_imgs

    def button_image_open(self):
        print(self.opt.conf_thres)
        print(self.opt.iou_thres)
        print('button_image_open')
        name_list = []
        try:
            img_name, _ = QtWidgets.QFileDialog.getOpenFileName(self, "打开图片", "data/images",
                                                                "*.jpg;;*.png;;All Files(*)")
        except OSError as reason:
            print('文件打开出错啦！核对路径是否正确' + str(reason))
        else:
            # 判断图片是否为空
            if not img_name:
                QtWidgets.QMessageBox.warning(self, u"Warning", u"打开图片失败", buttons=QtWidgets.QMessageBox.Ok,
                                              defaultButton=QtWidgets.QMessageBox.Ok)
            else:
                # 用 numpy 读取，避免 cv2.imread 不支持中文路径
                img = cv2.imdecode(np.fromfile(img_name, dtype=np.uint8), cv2.IMREAD_COLOR)
                print("img_name:", img_name)
                info_show = self.detect(name_list, img)
                # print(info_show)
                # 获取当前系统时间，作为img文件名
                now = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
                file_extension = img_name.split('.')[-1]
                new_filename = now + '.' + file_extension  # 获得文件后缀名
                file_path = self.output_folder + 'img_output/' + new_filename
                cv2.imwrite(file_path, info_show[3])
                # # 检测信息显示在界面
                if self.flag:
                    all_strs = info_show[5]  # 所有车牌字符串列表
                    a = '  |  '.join(all_strs) if all_strs else ''
                    # 地区判断用第一块牌
                    region_name, _ = identify_plate_region(all_strs[0]) if all_strs else ('未知', 'unknown')
                    self.label_18.setAlignment(Qt.AlignCenter)
                    self.label_18.setFont(QFont("Roman times", 16, QFont.Bold))
                    self.label_18.setText(a)
                    self.label_region.setAlignment(Qt.AlignCenter)
                    self.label_region.setFont(QFont("楷体", 16))
                    self.label_region.setText(region_name)
                    self.label_8.setAlignment(Qt.AlignCenter)
                    self.label_8.setFont(QFont("Roman times",16,QFont.Bold))
                    self.label_8.setText(info_show[1][6:])
                    self.label_11.setAlignment(Qt.AlignCenter)
                    self.label_11.setFont(QFont("Roman times", 16, QFont.Bold))
                    self.label_11.setText(str(info_show[0][0]))
                    self.label_13.setAlignment(Qt.AlignCenter)
                    self.label_13.setFont(QFont("Roman times", 16, QFont.Bold))
                    self.label_13.setText(str(info_show[0][1]))
                    self.label_16.setAlignment(Qt.AlignCenter)
                    self.label_16.setFont(QFont("Roman times", 16, QFont.Bold))
                    self.label_16.setText(str(info_show[0][2]))
                    self.label_17.setAlignment(Qt.AlignCenter)
                    self.label_17.setFont(QFont("Roman times", 16, QFont.Bold))
                    self.label_17.setText(str(info_show[0][3]))
                # 检测结果显示在界面
                self.result = cv2.cvtColor(info_show[3] if self.flag else img, cv2.COLOR_BGR2BGRA)
                self.result = cv2.resize(self.result, (720,576), interpolation=cv2.INTER_AREA)
                self.QtImg = QtGui.QImage(self.result.data, self.result.shape[1], self.result.shape[0],
                                          QtGui.QImage.Format_RGB32)
                self.piature_show.setPixmap(QtGui.QPixmap.fromImage(self.QtImg))
                self.piature_show.setScaledContents(True)

                # 显示各车牌缩略图（最多两个框）
                plate_imgs = info_show[6]  # [(plate_img, plate_str), ...]
                for idx, lbl in enumerate([self.label_plate, self.label_plate2]):
                    if idx < len(plate_imgs):
                        pi_img = plate_imgs[idx][0]
                        if pi_img is not None and pi_img.size > 0:
                            pi = cv2.cvtColor(pi_img, cv2.COLOR_BGR2BGRA)
                            pi = cv2.resize(pi, (188, 48), interpolation=cv2.INTER_AREA)
                            qimg = QtGui.QImage(pi.data, pi.shape[1], pi.shape[0], QtGui.QImage.Format_RGB32)
                            lbl.setPixmap(QtGui.QPixmap.fromImage(qimg))
                            lbl.setScaledContents(True)
                    else:
                        lbl.clear()
                self.flag = 0


    # 定义视频帧显示操作
    def show_video_frame(self):
        name_list = []
        flag, img = self.cap.read()
        if img is not None:
            start=time.time()
            info_show = self.detect(name_list, img)  # 检测结果写入到原始img上
            end = time.time()
            detect_time = end - start
            # print('FPS:{}'.format(1/detect_time))
            cv2.putText(info_show[3], 'FPS:{}'.format(int(1/detect_time)), (30,60), 0, 1, (255, 255, 0), thickness=2, lineType=cv2.LINE_AA)
            self.vid_writer.write(img)  # 检测结果写入视频
            # print(info_show)
            if self.flag:
                all_strs = info_show[5]
                a = '  |  '.join(all_strs) if all_strs else ''
                region_name, _ = identify_plate_region(all_strs[0]) if all_strs else ('未知', 'unknown')
                self.label_18.setAlignment(Qt.AlignCenter)
                self.label_18.setFont(QFont("Roman times", 16, QFont.Bold))
                self.label_18.setText(a)
                self.label_region.setAlignment(Qt.AlignCenter)
                self.label_region.setFont(QFont("楷体", 16))
                self.label_region.setText(region_name)
                self.label_8.setAlignment(Qt.AlignCenter)
                self.label_8.setFont(QFont("Roman times", 16, QFont.Bold))
                self.label_8.setText(info_show[1][6:])
                self.label_11.setAlignment(Qt.AlignCenter)
                self.label_11.setFont(QFont("Roman times", 16, QFont.Bold))
                self.label_11.setText(str(info_show[0][0]))
                self.label_13.setAlignment(Qt.AlignCenter)
                self.label_13.setFont(QFont("Roman times", 16, QFont.Bold))
                self.label_13.setText(str(info_show[0][1]))
                self.label_16.setAlignment(Qt.AlignCenter)
                self.label_16.setFont(QFont("Roman times", 16, QFont.Bold))
                self.label_16.setText(str(info_show[0][2]))
                self.label_17.setAlignment(Qt.AlignCenter)
                self.label_17.setFont(QFont("Roman times", 16, QFont.Bold))
                self.label_17.setText(str(info_show[0][3]))
                # 检测信息显示在界面
                # self.result = cv2.cvtColor(info_show[3], cv2.COLOR_BGR2BGRA)
            show = cv2.resize(info_show[3] if self.flag else img, (720, 576))
            self.result = cv2.cvtColor(show, cv2.COLOR_BGR2RGB)
            showImage = QtGui.QImage(self.result.data, self.result.shape[1], self.result.shape[0],
                                     QtGui.QImage.Format_RGB888)
            self.piature_show.setPixmap(QtGui.QPixmap.fromImage(showImage))
            self.piature_show.setScaledContents(True)

            # 显示各车牌缩略图（最多两个框）
            plate_imgs = info_show[6]
            for idx, lbl in enumerate([self.label_plate, self.label_plate2]):
                if idx < len(plate_imgs):
                    pi_img = plate_imgs[idx][0]
                    if pi_img is not None and pi_img.size > 0:
                        pi = cv2.cvtColor(pi_img, cv2.COLOR_BGR2BGRA)
                        pi = cv2.resize(pi, (188, 48), interpolation=cv2.INTER_AREA)
                        qimg = QtGui.QImage(pi.data, pi.shape[1], pi.shape[0], QtGui.QImage.Format_RGB32)
                        lbl.setPixmap(QtGui.QPixmap.fromImage(qimg))
                        lbl.setScaledContents(True)
                else:
                    lbl.clear()
            self.flag = 0

        else:
            self.timer_video.stop()
            # 读写结束，释放资源
            self.cap.release()  # 释放video_capture资源
            self.vid_writer.release()  # 释放video_writer资源
            self.piature_show.clear()
            self.label_plate.clear()
            # 视频帧显示期间，禁用其他检测按键功能
            self.pushButton_video.setDisabled(False)
            self.pushButton_img.setDisabled(False)
            self.pushButton_camer.setDisabled(False)

    def set_video_name_and_path(self):
        # 获取当前系统时间，作为img和video的文件名
        now = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime(time.time()))
        # if vid_cap:  # video
        fps = self.cap.get(cv2.CAP_PROP_FPS)
        w = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        # 视频检测结果存储位置
        save_path = self.output_folder + 'video_output/' + now + '.mp4'
        return fps, w, h, save_path

    def button_video_open(self):
        video_name, _ = QtWidgets.QFileDialog.getOpenFileName(self, "打开视频", "test_video/", "*.mp4;;*.avi;;All Files(*)")
        flag = self.cap.open(video_name)
        if not flag:
            QtWidgets.QMessageBox.warning(self, u"Warning", u"打开视频失败", buttons=QtWidgets.QMessageBox.Ok,defaultButton=QtWidgets.QMessageBox.Ok)
        else:
            #-------------------------写入视频----------------------------------#
            fps, w, h, save_path = self.set_video_name_and_path()
            self.vid_writer = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))

            self.timer_video.start(30) # 以30ms为间隔，启动或重启定时器
            # 进行视频识别时，关闭其他按键点击功能
            self.pushButton_2.setDisabled(True)
            self.pushButton_img.setDisabled(True)
            self.pushButton_3.setDisabled(True)

    # 打开摄像头检测
    def button_camera_open(self):
        print("Open camera to detect")
        # 设置使用的摄像头序号，系统自带为0
        camera_num = 0
        # 打开摄像头
        self.cap = cv2.VideoCapture(camera_num)
        # 判断摄像头是否处于打开状态
        bool_open = self.cap.isOpened()
        if not bool_open:
            QtWidgets.QMessageBox.warning(self, u"Warning", u"打开摄像头失败", buttons=QtWidgets.QMessageBox.Ok,
                                          defaultButton=QtWidgets.QMessageBox.Ok)
        else:
            fps, w, h, save_path = self.set_video_name_and_path()
            fps = 5 # 控制摄像头检测下的fps，Note：保存的视频，播放速度有点快，我只是粗暴的调整了FPS
            self.vid_writer = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))
            self.timer_video.start(30)
            self.pushButton_2.setDisabled(True)
            self.pushButton_img.setDisabled(True)
            self.pushButton_3.setDisabled(True)



    def button_video_stop(self):
        self.timer_video.blockSignals(False)
        # 暂停检测
        # 若QTimer已经触发，且激活
        if self.timer_video.isActive() == True and self.num_stop%2 == 1:
            self.pushButton_stop.setText(u'暂停检测') # 当前状态为暂停状态
            self.num_stop = self.num_stop + 1 # 调整标记信号为偶数
            self.timer_video.blockSignals(True)
        # 继续检测
        else:
            self.num_stop = self.num_stop + 1
            self.pushButton_stop.setText(u'继续检测')


    def finish_detect(self):
        self.timer_video.stop()
        self.cap.release()  # 释放video_capture资源
        self.vid_writer.release()  # 释放video_writer资源
        self.piature_show.clear() # 清空label画布
        # 启动其他检测按键功能
        self.pushButton_3.setDisabled(False)
        self.pushButton_2.setDisabled(False)
        self.pushButton_img.setDisabled(False)

        # 结束检测时，查看暂停功能是否复位，将暂停功能恢复至初始状态
        # Note:点击暂停之后，num_stop为偶数状态
        if self.num_stop%2 == 0:
            print("Reset stop/begin!")
            self.pushButton_stop.setText(u'暂停/继续')
            self.num_stop = self.num_stop + 1
            self.timer_video.blockSignals(False)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    # name=[]
    # img=cv2.imread("11.jpg")
    myWindow = mywindows()
    # myWindow.model_init()
    # myWindow.detect(name,img)
    myWindow.show()
    sys.exit(app.exec_())

