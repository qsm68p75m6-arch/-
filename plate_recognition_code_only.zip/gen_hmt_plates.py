# -*- coding: utf-8 -*-
"""
港澳台车牌合成数据生成脚本
输出目录结构：
  lprr/hmt_data/
    images/   *.jpg  (94x24)
    labels/   *.txt  (车牌字符串，如 AB1234)

用法：
  python gen_hmt_plates.py --num 3000 --out lprr/hmt_data
"""

import os
import random
import string
import argparse
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ---------------------------------------------------------------------------
# 车牌格式定义
# ---------------------------------------------------------------------------

def _rand_letters(n):
    # 香港/澳门/台湾车牌不含 I / O，避免与数字混淆
    pool = [c for c in string.ascii_uppercase if c not in ('I', 'O')]
    return ''.join(random.choices(pool, k=n))

def _rand_digits(n):
    return ''.join(random.choices(string.digits, k=n))

def gen_hk_plate():
    """香港私家车: AB·1234 或 AB·12345 或 A·1234"""
    fmt = random.choice(['L2D4', 'L2D5', 'L1D4'])
    if fmt == 'L2D4':
        return _rand_letters(2) + _rand_digits(4)
    elif fmt == 'L2D5':
        return _rand_letters(2) + _rand_digits(5)
    else:
        return _rand_letters(1) + _rand_digits(4)

def gen_mo_plate():
    """澳门私家车: AB·12·34 (去连字符后 AB1234) 或摩托 AB·12"""
    fmt = random.choice(['L2D4', 'L2D2'])
    return _rand_letters(2) + _rand_digits(4 if fmt == 'L2D4' else 2)

def gen_tw_plate():
    """台湾: 旧式 AB·1234, 新式 ABC·1234, 机车 ABC·123"""
    fmt = random.choice(['L2D4', 'L3D4', 'L3D3'])
    if fmt == 'L2D4':
        return _rand_letters(2) + _rand_digits(4)
    elif fmt == 'L3D4':
        return _rand_letters(3) + _rand_digits(4)
    else:
        return _rand_letters(3) + _rand_digits(3)

GENERATORS = {
    'hk': gen_hk_plate,
    'mo': gen_mo_plate,
    'tw': gen_tw_plate,
}

# ---------------------------------------------------------------------------
# 车牌背景颜色（各地区特征色）
# ---------------------------------------------------------------------------

REGION_COLORS = {
    'hk': {
        'bg': [(255, 255, 255), (240, 240, 240)],   # 白底
        'fg': [(0, 0, 0)],
    },
    'mo': {
        'bg': [(255, 255, 255), (245, 245, 220)],   # 白/米白底
        'fg': [(0, 0, 0)],
    },
    'tw': {
        'bg': [(255, 255, 255), (240, 248, 255)],   # 白底
        'fg': [(0, 0, 0), (0, 0, 180)],
    },
}

# ---------------------------------------------------------------------------
# 图像渲染
# ---------------------------------------------------------------------------

def load_font(font_path, size):
    try:
        return ImageFont.truetype(font_path, size)
    except Exception:
        return ImageFont.load_default()

def render_plate(text, region, font, img_w=94, img_h=24):
    """将车牌字符串渲染为 img_w x img_h 的 RGB 图像，并加入随机扰动。"""
    colors = REGION_COLORS[region]
    bg_color = random.choice(colors['bg'])
    fg_color = random.choice(colors['fg'])

    img = Image.new('RGB', (img_w, img_h), color=bg_color)
    draw = ImageDraw.Draw(img)

    # 计算文字居中位置
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    x = (img_w - tw) // 2 + random.randint(-2, 2)
    y = (img_h - th) // 2 + random.randint(-1, 1)

    draw.text((x, y), text, font=font, fill=fg_color)

    # 随机扰动：轻微模糊、噪声、亮度变化
    img = _augment(img)
    return img

def _augment(img):
    arr = np.array(img, dtype=np.float32)

    # 亮度扰动
    arr += random.uniform(-20, 20)
    arr = np.clip(arr, 0, 255)

    # 高斯噪声
    noise = np.random.normal(0, random.uniform(0, 8), arr.shape)
    arr = np.clip(arr + noise, 0, 255).astype(np.uint8)

    img = Image.fromarray(arr)

    # 随机轻微模糊
    if random.random() < 0.3:
        img = img.filter(ImageFilter.GaussianBlur(radius=random.uniform(0.3, 0.8)))

    return img

# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def generate(num_per_region, out_dir, font_path):
    img_dir = os.path.join(out_dir, 'images')
    lbl_dir = os.path.join(out_dir, 'labels')
    os.makedirs(img_dir, exist_ok=True)
    os.makedirs(lbl_dir, exist_ok=True)

    font = load_font(font_path, size=16)

    total = 0
    for region, gen_fn in GENERATORS.items():
        seen = set()
        count = 0
        while count < num_per_region:
            text = gen_fn()
            if text in seen:
                continue
            seen.add(text)

            img = render_plate(text, region, font)
            name = f'{region}_{count:05d}'
            img.save(os.path.join(img_dir, name + '.jpg'), quality=95)
            with open(os.path.join(lbl_dir, name + '.txt'), 'w') as f:
                f.write(text)

            count += 1
            total += 1
            if total % 500 == 0:
                print(f'  已生成 {total} 张...')

    print(f'完成，共生成 {total} 张图片，保存至 {out_dir}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--num', type=int, default=3000,
                        help='每个地区生成的图片数量（默认3000，共9000张）')
    parser.add_argument('--out', type=str, default='lprr/hmt_data',
                        help='输出目录')
    parser.add_argument('--font', type=str, default='Arial.ttf',
                        help='字体文件路径')
    args = parser.parse_args()

    print(f'生成港澳台车牌数据，每地区 {args.num} 张...')
    generate(args.num, args.out, args.font)
