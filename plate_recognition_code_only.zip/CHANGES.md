# 改动说明（相对原始版本）

## 一、车牌检测模型替换

**原版**：使用 YOLOv5 PyTorch 模型（`runs/train/exp29/weights/best.pt`），需要 CUDA GPU。

**新版**：替换为 YOLOv10n ONNX 模型，纯 CPU 推理，无需 GPU。

- 模型文件：`lprr/plate_detector_fp32.onnx`（2.3MB，FP32）
- 推理脚本：`lprr/infer_onnx.py`（`PlateDetectorONNX` 类）
- 输入：`[1, 3, 640, 640]` float32，归一化到 [0,1]
- 输出：`[1, 5, 8400]`，每个预测 `[cx, cy, w, h, conf]`，经 NMS 后返回 `[x1, y1, x2, y2, conf]`

---

## 二、新增港澳台/粤Z车牌识别能力

**原版**：仅支持大陆蓝牌，使用 LPRNet 识别。

**新版**：根据车牌底色自动选择识别引擎：

| 底色 | 车牌类型 | 识别引擎 |
|------|---------|---------|
| 蓝底白字 | 大陆标准牌 | LPRNet |
| 黄底黑字 | 香港车尾牌 | EasyOCR（中英文模型）|
| 黑底白字 | 粤Z跨境牌 | EasyOCR + 规则补全 |
| 白底黑字 | 香港车头牌/台湾牌 | EasyOCR |

**粤Z补全规则**：EasyOCR 识别出中间字母数字部分后，自动补全为 `粤Z·XXXX港` 格式。

---

## 三、双车牌检测（港澳跨境车）

**原版**：每张图只识别一块车牌。

**新版**：支持同时识别两块车牌（香港本地牌 + 粤Z跨境牌）。

- `lprr/color_detect.py`（新增）：颜色补充检测模块
  - 对黄底牌：在其下方搜索配对的粤Z牌
  - 对黑底粤Z牌：在其上方搜索香港本地牌
- UI 右下角新增第二个车牌缩略图显示框
- 图上标注：第一块牌显示在框右侧（红色），第二块牌显示在框右侧（青色）

---

## 四、LPRNet 识别优化

**原版**：直接取 argmax，无置信度过滤。

**新版**：
- 置信度阈值过滤：字符得分需明显高于 blank（前14位阈值 2.0，后4位阈值 8.0）
- 字符修正：第3位及以后 `U→0`、`I→1`、`O→0`
- 格式校验：多汉字截断（只保留第1个省份汉字）
- 长度限制：最多 8 个字符

---

## 五、新增/修改的文件

### 新增文件
| 文件 | 说明 |
|------|------|
| `lprr/infer_onnx.py` | ONNX 推理类（从 `交付/scripts/infer_onnx.py` 移入） |
| `lprr/plate_detector_fp32.onnx` | YOLOv10n 车牌检测模型（从 `交付/model/` 移入） |
| `lprr/color_detect.py` | 颜色补充检测模块 |
| `lprr/hmt_ocr.py` | 港澳台车牌 EasyOCR 识别模块 |
| `vendor/` | 本地 onnxruntime 1.21.0（解决 Python 3.13 DLL 兼容问题） |

### 修改文件
| 文件 | 主要改动 |
|------|---------|
| `main.py` | 检测引擎从 YOLOv5 改为 ONNX；支持双车牌显示；标注位置改为框右侧 |
| `lprr/plate.py` | 新增颜色判断、EasyOCR 路径、粤Z补全、LPRNet 置信度过滤 |
| `lprr/LPRNet.py` | 新增 `identify_plate_region` 函数（地区判断） |
| `ui/main_window.py` | 新增第二个车牌缩略图 label（`label_plate2`） |
| `lprr/plate.py` | `de_lpr` 返回值从 2 个改为 3 个（增加 `plate_str`） |

---

## 六、依赖变化

### 新增依赖
```
onnxruntime==1.21.0   # 车牌检测推理（本地 vendor 目录已包含）
easyocr               # 港澳台车牌 OCR（需 pip install）
pytesseract           # 备用 OCR（可选）
```

### 移除依赖
- 不再需要 CUDA / GPU
- 不再需要 YOLOv5 的 `torch` 推理路径（仅 LPRNet 仍用 torch）

---

## 七、运行方式

```bash
# 安装依赖
pip install easyocr onnxruntime

# 运行
cd master_liu-master
python main.py
```

首次运行 EasyOCR 会自动下载中英文模型（约 100MB），之后缓存在 `~/.EasyOCR/`。

---

## 八、模型文件位置

| 模型 | 路径 | 用途 |
|------|------|------|
| YOLOv10n ONNX | `lprr/plate_detector_fp32.onnx` | 车牌区域检测 |
| LPRNet | `lprr/Final_LPRNet_model.pth` | 大陆蓝牌字符识别 |
| EasyOCR（自动下载） | `~/.EasyOCR/model/` | 港澳台/粤Z字符识别 |
