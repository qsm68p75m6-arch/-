# coding=utf-8
"""
LPRNet —— License Plate Recognition Network
原始论文: https://arxiv.org/abs/1806.10447

改动说明：
  1. 字符集统一从 chars_config.py 导入，不再在此文件硬编码
  2. build_lprnet 的 class_num 默认值改为从配置读取，避免新旧字符集不一致
  3. 新增 expand_output_layer()：将旧权重（68类）迁移到新字符集（77类）
     迁移仅扩展输出层 class_num，不改变 backbone 通道数或卷积核尺寸
"""

import os
import torch
import torch.nn as nn

from lprr.chars_config import (
    CHARS, CHARS_ORIGINAL, CHARS_FULL,
    ORIGINAL_CLASS_NUM, FULL_CLASS_NUM,
    CHAR2IDX_ORIGINAL, CHAR2IDX_FULL,
)

# ── 输入图像尺寸 ──────────────────────────────────────────────────────────────
INPUT_W = 94   # 宽度：与原始 LPRNet 一致，保证序列长度 W=18
INPUT_H = 48   # 高度：升级到 48，中文笔画清晰度大幅提升（原始为 24）


class small_basic_block(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(small_basic_block, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(ch_in, ch_out // 4, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(ch_out // 4, ch_out // 4, kernel_size=(3, 1), padding=(1, 0)),
            nn.ReLU(),
            nn.Conv2d(ch_out // 4, ch_out // 4, kernel_size=(1, 3), padding=(0, 1)),
            nn.ReLU(),
            nn.Conv2d(ch_out // 4, ch_out, kernel_size=1),
        )

    def forward(self, x):
        return self.block(x)


class LPRNet(nn.Module):
    def __init__(self, lpr_max_len, phase, class_num, dropout_rate):
        super(LPRNet, self).__init__()
        self.phase = phase
        self.lpr_max_len = lpr_max_len
        self.class_num = class_num
        self.backbone = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=64, kernel_size=3, stride=1),   # 0
            nn.BatchNorm2d(num_features=64),                                       # 1
            nn.ReLU(),                                                              # 2  ← kf[0]
            nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(1, 1, 1)),                 # 3
            small_basic_block(ch_in=64, ch_out=128),                               # 4
            nn.BatchNorm2d(num_features=128),                                      # 5
            nn.ReLU(),                                                              # 6  ← kf[1]
            nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(2, 1, 2)),                 # 7
            small_basic_block(ch_in=64, ch_out=256),                               # 8
            nn.BatchNorm2d(num_features=256),                                      # 9
            nn.ReLU(),                                                              # 10
            small_basic_block(ch_in=256, ch_out=256),                              # 11
            nn.BatchNorm2d(num_features=256),                                      # 12
            nn.ReLU(),                                                              # 13 ← kf[2]
            nn.MaxPool3d(kernel_size=(1, 3, 3), stride=(4, 1, 2)),                 # 14
            nn.Dropout(dropout_rate),                                               # 15
            nn.Conv2d(in_channels=64, out_channels=256, kernel_size=(1, 4), stride=1),  # 16
            nn.BatchNorm2d(num_features=256),                                      # 17
            nn.ReLU(),                                                              # 18
            nn.Dropout(dropout_rate),                                               # 19
            nn.Conv2d(in_channels=256, out_channels=class_num, kernel_size=(13, 1), stride=1),  # 20
            nn.BatchNorm2d(num_features=class_num),                                # 21
            nn.ReLU(),                                                              # 22 ← kf[3]
        )
        self.container = nn.Sequential(
            nn.Conv2d(
                in_channels=448 + self.class_num,
                out_channels=self.class_num,
                kernel_size=(1, 1),
                stride=(1, 1)
            ),
        )

    def forward(self, x):
        keep_features = []
        for i, layer in enumerate(self.backbone.children()):
            x = layer(x)
            if i in [2, 6, 13, 22]:
                keep_features.append(x)

        adaptive_pool = nn.AdaptiveAvgPool2d((1, 18))
        global_context = []
        for f in keep_features:
            f_pow = torch.pow(f, 2)
            f_mean = torch.mean(f_pow)
            f = torch.div(f, f_mean)
            f = adaptive_pool(f)
            global_context.append(f)

        x = torch.cat(global_context, 1)   # [B, 64+128+256+class_num, 1, 18]
        x = self.container(x)              # [B, class_num, 1, 18]
        logits = torch.mean(x, dim=2)      # [B, class_num, 18]
        return logits


def build_lprnet(lpr_max_len=8, phase=False, class_num=None, dropout_rate=0.5):
    """
    构建 LPRNet 模型。

    Args:
        lpr_max_len:  车牌最大字符数，普通牌7位，新能源牌8位，默认8
        phase:        'train' 返回训练模式，其他值返回推理模式
        class_num:    字符类别数，None 时自动从 chars_config 读取当前配置
        dropout_rate: Dropout 比率

    Returns:
        LPRNet 实例（train 或 eval 模式）
    """
    if class_num is None:
        class_num = len(CHARS)

    net = LPRNet(lpr_max_len, phase, class_num, dropout_rate)

    if phase == "train":
        return net.train()
    else:
        return net.eval()


def expand_output_layer(old_model_path, new_model_path=None, device=None):
    """
    将原始 68 类模型权重迁移到 77 类（完整国标字符集）。

    迁移策略（仅扩展 class_num，不改变 backbone 通道数或卷积核）：
      - backbone 结构完全保持不变（256通道, kernel(13,1)）
      - 仅扩展与 class_num 相关的层：backbone.20, backbone.21, container.0
      - 旧字符集中已有的字符：直接复制对应权重
      - 新增字符（港/澳/使/领/警/学/挂/试/练）：用旧汉字权重均值初始化

    Args:
        old_model_path: 原始预训练权重路径（68类）
        new_model_path: 扩展后权重保存路径，None 则不保存
        device:         torch.device，None 时自动选择

    Returns:
        扩展后的 LPRNet 模型（77类，eval 模式）
    """
    if device is None:
        device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # 加载旧权重
    old_state = torch.load(old_model_path, map_location=device)

    # 构建新模型（77类，同样的原始架构）
    new_net = build_lprnet(lpr_max_len=8, phase=False,
                           class_num=FULL_CLASS_NUM, dropout_rate=0.5)
    new_state = new_net.state_dict()

    # 建立旧字符集 index → 新字符集 index 的映射
    old_to_new = {}
    for old_idx, char in enumerate(CHARS_ORIGINAL):
        if char in CHAR2IDX_FULL:
            old_to_new[old_idx] = CHAR2IDX_FULL[char]

    # 新增字符的 index（在新字符集中）
    new_char_indices = [
        CHAR2IDX_FULL[c] for c in CHARS_FULL
        if c not in CHAR2IDX_ORIGINAL
    ]
    # 旧字符集中汉字的 index（用于计算均值初始化新汉字）
    old_hanzi_indices = list(range(31))  # 0-30 是省份简称

    print(f'[expand] 旧字符集: {ORIGINAL_CLASS_NUM} 类 → 新字符集: {FULL_CLASS_NUM} 类')
    print(f'[expand] 新增字符 ({len(new_char_indices)} 个): '
          f'{[CHARS_FULL[i] for i in new_char_indices]}')

    for key in new_state.keys():
        if key not in old_state:
            print(f'[expand] 跳过（旧模型无此层）: {key}')
            continue

        old_tensor = old_state[key]
        new_tensor = new_state[key]

        # 形状相同，直接复制（backbone 前面的层不涉及 class_num）
        if old_tensor.shape == new_tensor.shape:
            new_state[key] = old_tensor.clone()
            continue

        # 形状不同 → class_num 相关层（backbone.20, backbone.21, container.0）
        if 'container.0.weight' in key:
            _copy_container_weight(new_state, key, old_tensor, new_tensor,
                                   old_to_new, new_char_indices, old_hanzi_indices)
        else:
            _copy_output_dim(new_state, key, old_tensor, new_tensor,
                             old_to_new, new_char_indices, old_hanzi_indices,
                             dim=0)
        print(f'[expand] 扩展: {key} {old_tensor.shape} → {new_tensor.shape}')

    new_net.load_state_dict(new_state)
    new_net.eval()

    if new_model_path:
        torch.save(new_net.state_dict(), new_model_path)
        print(f'[expand] 扩展后权重已保存到: {new_model_path}')

    return new_net


def _copy_output_dim(new_state, key, old_tensor, new_tensor,
                     old_to_new, new_char_indices, old_hanzi_indices, dim=0):
    """按字符映射复制输出维度（dim=0）的权重。"""
    result = new_tensor.clone()

    # 1. 复制旧字符对应的权重
    for old_idx, new_idx in old_to_new.items():
        idx_old = [slice(None)] * old_tensor.dim()
        idx_new = [slice(None)] * result.dim()
        idx_old[dim] = old_idx
        idx_new[dim] = new_idx
        result[tuple(idx_new)] = old_tensor[tuple(idx_old)]

    # 2. 新增字符用旧汉字均值初始化
    idx_old_hanzi = [slice(None)] * old_tensor.dim()
    idx_old_hanzi[dim] = old_hanzi_indices
    hanzi_mean = old_tensor[tuple(idx_old_hanzi)].mean(dim=dim, keepdim=True)
    # hanzi_mean shape: [1, ...] 或 [1]

    for new_idx in new_char_indices:
        idx_new = [slice(None)] * result.dim()
        idx_new[dim] = new_idx
        if result.dim() == 1:
            result[new_idx] = hanzi_mean.squeeze()
        else:
            result[tuple(idx_new)] = hanzi_mean.squeeze(dim)

    new_state[key] = result


def _copy_container_weight(new_state, key, old_tensor, new_tensor,
                            old_to_new, new_char_indices, old_hanzi_indices):
    """
    复制 container.0.weight，形状 [new_class, 448+new_class, 1, 1]。
    输出维度 (dim=0) 和输入维度中 class_num 部分 (dim=1, offset=448) 都要扩展。
    """
    old_class = ORIGINAL_CLASS_NUM  # 68
    new_class = FULL_CLASS_NUM      # 77
    result = new_tensor.clone()

    # ── 先处理输出维度 (dim=0) ──────────────────────────────────────────────
    # 旧 weight: [68, 448+68, 1, 1] = [68, 516, 1, 1]
    # 新 weight: [77, 448+77, 1, 1] = [77, 525, 1, 1]

    # 对于输入维度，旧的 448+68=516 通道中：
    #   前 448 通道：backbone 特征，直接复制
    #   后 68 通道：旧字符集的 class 通道，需要按映射扩展到 77 通道

    # 构建输入维度的映射（旧 516 → 新 525）
    # 前 448 通道直接对应
    # 后 68 通道按 old_to_new 映射到新的 77 通道位置

    for old_out_idx, new_out_idx in old_to_new.items():
        # 复制前 448 个输入通道
        result[new_out_idx, :448, :, :] = old_tensor[old_out_idx, :448, :, :]
        # 复制后 class_num 个输入通道（按字符映射）
        for old_in_idx, new_in_idx in old_to_new.items():
            result[new_out_idx, 448 + new_in_idx, :, :] = \
                old_tensor[old_out_idx, 448 + old_in_idx, :, :]

    # 新增字符的输出行：用旧汉字行均值初始化
    old_hanzi_rows = old_tensor[old_hanzi_indices, :, :, :]  # [31, 516, 1, 1]
    hanzi_mean_row = old_hanzi_rows.mean(dim=0, keepdim=True)  # [1, 516, 1, 1]

    for new_out_idx in new_char_indices:
        # 前 448 通道
        result[new_out_idx, :448, :, :] = hanzi_mean_row[0, :448, :, :]
        # 后 class_num 通道：新增字符对应的输入通道也用均值
        for old_in_idx, new_in_idx in old_to_new.items():
            result[new_out_idx, 448 + new_in_idx, :, :] = \
                hanzi_mean_row[0, 448 + old_in_idx, :, :]
        # 新增字符对应的输入通道（新增字符的输入通道）用小随机值
        for new_in_idx in new_char_indices:
            result[new_out_idx, 448 + new_in_idx, :, :] = \
                torch.randn_like(result[new_out_idx, 448 + new_in_idx, :, :]) * 0.01

    new_state[key] = result
