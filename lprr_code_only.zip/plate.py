# coding=utf-8
"""
车牌识别模块（LPRNet 推理）

设计原则：
  - CHARS 在 chars_config.py 中静态定义为 CHARS_FULL（77类），全局唯一
  - 优先加载已训练的 77 类模型（Final_LPRNet_model_full.pth）
  - 若不存在，自动从原始 68 类权重扩展并保存，下次直接加载
  - 模型单例，全局只初始化一次
"""

import os
import numpy as np
import cv2
import torch

from lprr.LPRNet import build_lprnet, expand_output_layer, INPUT_W, INPUT_H
from lprr.chars_config import (
    CHARS,                  # 始终是 CHARS_FULL（77类）
    ORIGINAL_CLASS_NUM,
    FULL_CLASS_NUM,
    SPECIAL_CHARS,
    NEW_ENERGY_SUFFIX,
)

# ── 模型文件路径 ──────────────────────────────────────────────────────────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_MODEL_ORIGINAL = os.path.join(_THIS_DIR, 'Final_LPRNet_model.pth')
_MODEL_FULL     = os.path.join(_THIS_DIR, 'Final_LPRNet_model_full.pth')

# ── 单例 ──────────────────────────────────────────────────────────────────────
_lprnet = None
_device = None


def _get_lprnet():
    """
    懒加载 LPRNet，全局只初始化一次。

    加载策略：
      1. 若 Final_LPRNet_model_full.pth 存在 → 直接加载（77类）
      2. 若只有 Final_LPRNet_model.pth（68类）→ 自动扩展并保存为 _full.pth
    """
    global _lprnet, _device
    if _lprnet is not None:
        return _lprnet, _device

    _device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    if os.path.exists(_MODEL_FULL):
        # 直接加载完整模型
        _lprnet = build_lprnet(lpr_max_len=8, phase=False,
                               class_num=FULL_CLASS_NUM, dropout_rate=0.5)
        _lprnet.to(_device)
        state = torch.load(_MODEL_FULL, map_location=_device)
        # 兼容 float16 保存的权重
        state = {k: v.float() if v.dtype == torch.float16 else v
                 for k, v in state.items()}
        _lprnet.load_state_dict(state)
        _lprnet.eval()
        size_kb = os.path.getsize(_MODEL_FULL) / 1024
        print(f'[LPRNet] 加载完整国标模型（{FULL_CLASS_NUM}类，{size_kb:.0f}KB）')

    elif os.path.exists(_MODEL_ORIGINAL):
        # 首次运行：自动扩展旧模型并保存
        print(f'[LPRNet] 首次运行，自动扩展 68→77 类并保存...')
        _lprnet = expand_output_layer(
            old_model_path=_MODEL_ORIGINAL,
            new_model_path=_MODEL_FULL,
            device=_device,
        )
        _lprnet.to(_device)
        print(f'[LPRNet] 扩展完成，已保存: {_MODEL_FULL}')
        print(f'[LPRNet] 提示：新字符识别需微调，运行 train_finetune.py 获得最佳效果')

    else:
        raise FileNotFoundError(
            f'未找到 LPRNet 权重文件，请确认以下文件之一存在：\n'
            f'  {_MODEL_FULL}\n'
            f'  {_MODEL_ORIGINAL}'
        )

    print(f'[LPRNet] 就绪，设备: {_device}，字符集: {len(CHARS)} 类')
    return _lprnet, _device


def _transform(img):
    """图像预处理：归一化 + CHW 转置。"""
    img = img.astype('float32') / 255.0
    img = np.transpose(img, (2, 0, 1))
    return img


def _ctc_decode(preb):
    """CTC 贪心解码，去除重复字符和空白符。"""
    blank_idx = len(CHARS) - 1
    preb_label = [int(np.argmax(preb[:, j])) for j in range(preb.shape[1])]

    result = []
    prev = preb_label[0]
    if prev != blank_idx:
        result.append(prev)
    for c in preb_label[1:]:
        if c == prev or c == blank_idx:
            if c == blank_idx:
                prev = c
            continue
        result.append(c)
        prev = c
    return result


def _postprocess(char_indices):
    """基于国标规则做后处理：普通牌第二位 I→1，O→0。"""
    if not char_indices:
        return char_indices, 'unknown'

    char_list = [CHARS[i] for i in char_indices]
    plate_type = 'normal'

    if char_list and char_list[0] in SPECIAL_CHARS:
        plate_type = 'special'
    elif len(char_list) >= 8 and char_list[-1] in NEW_ENERGY_SUFFIX:
        plate_type = 'new_energy'

    if plate_type == 'normal' and len(char_list) >= 2:
        if char_list[1] == 'I' and '1' in CHARS:
            char_indices[1] = CHARS.index('1')
        elif char_list[1] == 'O' and '0' in CHARS:
            char_indices[1] = CHARS.index('0')

    return char_indices, plate_type


def de_lpr(coord, im0):
    """
    从原图裁剪车牌区域并识别字符。

    Returns:
        plat_num:  numpy array [1, n_chars]，字符索引（对应 CHARS）
        plate_img: numpy array，裁剪缩放后的车牌图像
    """
    x1, y1, x2, y2 = int(coord[0]), int(coord[1]), int(coord[2]), int(coord[3])
    h, w = im0.shape[:2]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)

    if x2 <= x1 or y2 <= y1:
        print('[LPRNet] 警告：车牌裁剪区域无效')
        return np.array([[]]), np.zeros((INPUT_H, INPUT_W, 3), dtype=np.uint8)

    crop = im0[y1:y2, x1:x2]
    plate_img = cv2.resize(crop, (INPUT_W, INPUT_H))

    im = _transform(plate_img)
    ims = torch.tensor(np.array([im]))

    lprnet, device = _get_lprnet()

    with torch.no_grad():
        prebs = lprnet(ims.to(device)).cpu().numpy()

    preb_labels = []
    for i in range(prebs.shape[0]):
        indices = _ctc_decode(prebs[i])
        indices, _ = _postprocess(indices)
        preb_labels.append(indices)

    if preb_labels and all(len(r) == len(preb_labels[0]) for r in preb_labels):
        plat_num = np.array(preb_labels)
    else:
        plat_num = np.empty(len(preb_labels), dtype=object)
        for i, row in enumerate(preb_labels):
            plat_num[i] = row

    return plat_num, plate_img


def decode_plate_number(plat_num):
    """将字符索引数组转换为车牌号码字符串。"""
    if plat_num is None or plat_num.size == 0:
        return ''
    try:
        return ''.join(CHARS[i] for i in plat_num[0])
    except (IndexError, TypeError):
        return ''


def reset_lprnet():
    """重置单例，下次调用重新加载模型。"""
    global _lprnet, _device
    _lprnet = None
    _device = None
    print('[LPRNet] 模型已重置。')
